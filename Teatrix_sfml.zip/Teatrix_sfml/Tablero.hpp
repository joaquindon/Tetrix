#pragma once
#include <vector>

class Tablero
{
	std::vector<Position> tabla;
private:
	Tablero(unsigned char shape);

	bool caida(const std::vector<std::vector<unsigned char>>& matriz);

	void reset(unsigned char shape);
	void actualizarMatriz(std::vector<std::vector<unsigned char>>& matriz)
		std::vector<Position> get_tabla();
public:

}